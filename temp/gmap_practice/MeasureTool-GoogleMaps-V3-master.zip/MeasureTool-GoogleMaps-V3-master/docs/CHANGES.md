# Changes
## v0.1.4
*Released on 03/21/2018*
- **[Bug Fix]** Fixed a newly introduced initialization bug caused from v0.1.2. Details see [#34](https://github.com/zhenyanghua/MeasureTool-GoogleMaps-V3/issues/34).

## v0.1.2
*Released on 03/20/2018*
- **[Bug Fix]** Fixed an overlay bug. Details see [#12](https://github.com/zhenyanghua/MeasureTool-GoogleMaps-V3/issues/12).

## v0.1.1
*Released on 03/19/2018*
- **[Bug Fix]** Updated `MeasureResult` in `measure_end` listener.

## v0.1.0
*Released on 03/18/2018*
- **[New Feature]** Added `Array<Segment>` to the `MeasureResult`. Example see [#31](https://github.com/zhenyanghua/MeasureTool-GoogleMaps-V3/issues/31).
