<?php
	echo $n;
?>