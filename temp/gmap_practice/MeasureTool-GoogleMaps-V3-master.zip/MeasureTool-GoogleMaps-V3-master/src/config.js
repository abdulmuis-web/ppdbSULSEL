export const Config  = {
  prefix: "measure-tool",
  tooltipText1: 'Drag to change, click to remove',
  tooltipText2: 'Drag to change'
};