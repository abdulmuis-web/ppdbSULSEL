<?php
	echo "
	<div class='row'>
	<div class='col-md-6'>
	<h1 style='font-size:2.5em' id='counter".$i."'>".number_format($t)."</h1>Orang</div>
	<div class='col-md-6'>
	<table class='table table-bordered'>
	<tbody>
		<tr><td><b>L</b>:</td><td align='right'>".number_format($l)."</td></tr>
		<tr><td><b>P</b>:</td><td align='right'>".number_format($p)."</td></tr>
	</tbody>
	</table>
	</div>";
?>